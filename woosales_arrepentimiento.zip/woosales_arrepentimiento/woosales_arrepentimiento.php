<?php
/**
 * Plugin Name:     Botón de Arrepentimiento Argentina — WooSales
 * Plugin URI:      https://github.com/gonbellido/woosales_arrepentimiento
 * Description:     Botón de Arrepentimiento Argentina para WooCommerce. Cumplí con la Ley 24.240 de Defensa del Consumidor. Formulario público, código de trámite inmediato, seguimiento y gestión simple de reclamaciones.
 * Version:         1.0.0
 * Author:          WooSales.pro
 * Author URI:      https://woosales.pro
 * License:         GPL-2.0+
 * License URI:     http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:     woosales-arrepentimiento
 * Domain Path:     /languages
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * WC requires at least: 5.0
 * WC tested up to:   9.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WA_VERSION', '1.0.0');
define('WA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WA_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Verifica que WooCommerce esté activo.
 */
function wa_check_woocommerce(): void
{
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            printf(
                '<div class="notice notice-error"><p>%s</p></div>',
                esc_html__('WooSales Arrepentimiento requiere WooCommerce activo.', 'woosales-arrepentimiento')
            );
        });
        return;
    }

    require_once WA_PLUGIN_DIR . 'includes/class-wa-loader.php';
    \WoosalesArrepentimiento\WA_Loader::init();
}

add_action('plugins_loaded', 'wa_check_woocommerce', 20);

/**
 * Botón de Arrepentimiento en el footer.
 */
function wa_boton_footer(): void
{
    $activado = get_option('wa_boton_footer', '1');
    if ($activado !== '1') {
        return;
    }

    $pagina_id = get_option('wa_pagina_formulario', '');
    $url = $pagina_id ? get_permalink((int) $pagina_id) : '#';
    $texto = get_option('wa_boton_texto', 'Botón de Arrepentimiento');

    if (!$pagina_id) {
        return; // Sin página configurada, no mostrar
    }

    ?>
    <div class="wa-footer-btn-wrap">
        <a href="<?php echo esc_url($url); ?>" class="wa-footer-btn" title="<?php esc_attr_e('Ejercer derecho de arrepentimiento — Ley 24.240', 'woosales-arrepentimiento'); ?>">
            ↺ <?php echo esc_html($texto); ?>
        </a>
    </div>
    <?php
}
add_action('wp_footer', 'wa_boton_footer', 100);

// Encolar CSS del botón footer globalmente
function wa_enqueue_footer_css(): void
{
    $activado = get_option('wa_boton_footer', '1');
    if ($activado === '1') {
        wp_enqueue_style('wa-form-css', WA_PLUGIN_URL . 'assets/css/wa-form.css', [], WA_VERSION);
    }
}
add_action('wp_enqueue_scripts', 'wa_enqueue_footer_css');
