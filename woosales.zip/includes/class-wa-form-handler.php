<?php
/**
 * Maneja el shortcode del formulario público y la creación de reclamaciones vía AJAX.
 *
 * @package WoosalesArrepentimiento
 */

namespace WoosalesArrepentimiento;

if (!defined('ABSPATH')) {
    exit;
}

class WA_Form_Handler
{
    /**
     * Flag para saber si el botón se usó en esta request.
     */
    private static $boton_usado = false;

    public function __construct()
    {
        add_shortcode('wa_formulario_arrepentimiento', [$this, 'render_form']);
        add_shortcode('wa_boton_arrepentimiento', [$this, 'render_boton']);
        add_action('wp_ajax_wa_enviar_reclamacion', [$this, 'handle_submission']);
        add_action('wp_ajax_nopriv_wa_enviar_reclamacion', [$this, 'handle_submission']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    /**
     * Encolar assets del formulario.
     */
    public function enqueue_assets(): void
    {
        // Always register so shortcode callbacks can enqueue on demand (page builders, widgets, etc.)
        wp_register_style('wa-form-css', WA_PLUGIN_URL . 'assets/css/wa-form.css', [], WA_VERSION);
        wp_register_script('wa-form-js', WA_PLUGIN_URL . 'assets/js/wa-form.js', ['jquery'], WA_VERSION, true);

        // Early enqueue for standard singular pages (avoids FOUC / late-enqueue edge cases)
        if (is_singular()) {
            $content = get_post()->post_content ?? '';
            if (
                has_shortcode($content, 'wa_formulario_arrepentimiento') ||
                has_shortcode($content, 'wa_boton_arrepentimiento')
            ) {
                $this->do_enqueue_assets();
            }
        }
    }

    /**
     * Encolar y localizar assets. Seguro llamarlo múltiples veces (idempotente).
     */
    private function do_enqueue_assets(): void
    {
        if (wp_script_is('wa-form-js', 'enqueued')) {
            return;
        }
        wp_enqueue_style('wa-form-css');
        wp_enqueue_script('wa-form-js');
        wp_localize_script('wa-form-js', 'WA_Form', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('wa_form_nonce'),
            'text'     => [
                'success_title'   => __('¡Solicitud Enviada!', 'woosales-arrepentimiento'),
                'error_generic'   => __('Ocurrió un error. Intentalo de nuevo.', 'woosales-arrepentimiento'),
                'error_order'     => __('El número de pedido no es válido.', 'woosales-arrepentimiento'),
                'error_duplicate' => __('Ya existe una reclamación activa para este pedido.', 'woosales-arrepentimiento'),
                'sending'         => __('Enviando...', 'woosales-arrepentimiento'),
                'submit_btn'      => __('Enviar Solicitud de Arrepentimiento', 'woosales-arrepentimiento'),
            ],
        ]);
    }

    /**
     * Renderizar formulario vía shortcode [wa_formulario_arrepentimiento].
     */
    public function render_form(): string
    {
        $this->do_enqueue_assets();
        $wa_texto_legal = WA_Settings::get_legal_text();
        $wa_captcha     = self::generar_captcha();
        ob_start();
        include WA_PLUGIN_DIR . 'templates/form-reclamacion.php';
        return ob_get_clean();
    }

    /**
     * Renderizar botón que abre el modal vía shortcode [wa_boton_arrepentimiento].
     *
     * Atributos:
     *   texto  — Texto del botón (default: "Botón de Arrepentimiento")
     *   class  — Clases CSS extra
     */
    public function render_boton(array $atts = []): string
    {
        $this->do_enqueue_assets();
        $es_primera_vez = !self::$boton_usado;
        self::$boton_usado = true;

        $atts = shortcode_atts([
            'texto' => __('Botón de Arrepentimiento', 'woosales-arrepentimiento'),
            'class' => '',
        ], $atts, 'wa_boton_arrepentimiento');

        $boton = sprintf(
            '<button type="button" class="wa-popup-trigger %s" onclick="WA_Modal.open()">%s</button>',
            esc_attr($atts['class']),
            esc_html($atts['texto'])
        );

        // Renderizar modal solo la primera vez
        $modal = '';
        if ($es_primera_vez) {
            $wa_texto_legal = WA_Settings::get_legal_text();
            $wa_captcha     = self::generar_captcha();
            ob_start();
            ?>
            <div class="wa-modal-overlay" id="wa-modal" style="display:none;">
                <div class="wa-modal-box">
                    <button type="button" class="wa-modal-close" onclick="WA_Modal.close()" aria-label="<?php esc_attr_e('Cerrar', 'woosales-arrepentimiento'); ?>">&times;</button>
                    <div class="wa-modal-body">
                        <?php include WA_PLUGIN_DIR . 'templates/form-reclamacion.php'; ?>
                    </div>
                </div>
            </div>
            <?php
            $modal = ob_get_clean();
        }

        return $boton . $modal;
    }

    /**
     * Genera pregunta CAPTCHA y guarda respuesta en transient (single-use, 2h).
     */
    public static function generar_captcha(): array
    {
        $a      = wp_rand(1, 9);
        $b      = wp_rand(1, 9);
        $token  = wp_generate_password(20, false);

        set_transient('wa_captcha_' . $token, $a + $b, 2 * HOUR_IN_SECONDS);

        return [
            'token'    => $token,
            'question' => sprintf(
                /* translators: %1$d y %2$d son números */
                __('¿Cuánto es %1$d + %2$d?', 'woosales-arrepentimiento'),
                $a, $b
            ),
        ];
    }

    /**
     * Valida respuesta CAPTCHA. Borra el transient (single-use).
     */
    private static function validar_captcha(string $token, string $respuesta): bool
    {
        if (empty($token) || !is_numeric($respuesta)) {
            return false;
        }

        $esperado = get_transient('wa_captcha_' . $token);
        delete_transient('wa_captcha_' . $token);

        return $esperado !== false && (int) $respuesta === (int) $esperado;
    }

    /**
     * Generar código de trámite único.
     * Formato: {3digitos}-{nro_pedido}-{fechaYmd}
     */
    private function generar_codigo(string $pedido_id): string
    {
        $fecha = current_time('Ymd');

        // Intentar hasta 5 veces para evitar colisiones
        for ($i = 0; $i < 5; $i++) {
            $rand    = str_pad((string) wp_rand(0, 999), 3, '0', STR_PAD_LEFT);
            $codigo  = $rand . '-' . $pedido_id . '-' . $fecha;

            // Verificar unicidad
            $existente = get_posts([
                'post_type'      => WA_Post_Type::CPT_SLUG,
                'meta_key'       => '_wa_codigo_tramite',
                'meta_value'     => $codigo,
                'posts_per_page' => 1,
                'post_status'    => ['private', 'publish'],
                'fields'         => 'ids',
            ]);

            if (empty($existente)) {
                return $codigo;
            }
        }

        // Si después de 5 intentos colisiona (extremadamente improbable), usar microtime
        $rand = str_pad((string) wp_rand(0, 999), 3, '0', STR_PAD_LEFT);
        $extra = str_pad((string) wp_rand(0, 9999), 4, '0', STR_PAD_LEFT);
        return $rand . '-' . $pedido_id . '-' . $fecha . '-' . $extra;
    }

    /**
     * Validar fechas contra la Ley 24.240.
     * Retorna array con advertencias, o vacío si está ok.
     */
    private function validar_fechas_legales(string $pedido_id, string $fecha_reserva = ''): array
    {
        $advertencias = [];
        $order = wc_get_order($pedido_id);

        if (!$order) {
            return $advertencias;
        }

        $fecha_compra = $order->get_date_created();
        if (!$fecha_compra) {
            return $advertencias;
        }

        $hoy = new \DateTime(current_time('Y-m-d'));
        $compra = new \DateTime($fecha_compra->date('Y-m-d'));
        $dias_transcurridos = (int) $hoy->diff($compra)->days;

        if ($dias_transcurridos > 10) {
            $advertencias[] = sprintf(
                __('Han transcurrido %d días desde la compra. El plazo legal de 10 días corridos (Ley 24.240) podría haber vencido.', 'woosales-arrepentimiento'),
                $dias_transcurridos
            );
        }

        if (!empty($fecha_reserva)) {
            $reserva = new \DateTime(sanitize_text_field($fecha_reserva));
            $dias_para_reserva = (int) $hoy->diff($reserva)->days;
            $reserva_pasada = $reserva < $hoy;

            if ($reserva_pasada) {
                $advertencias[] = __('La fecha de la reserva ya transcurrió. El derecho de arrepentimiento podría no ser aplicable.', 'woosales-arrepentimiento');
            } elseif ($dias_para_reserva < 2) {
                $advertencias[] = __('Faltan menos de 48 horas hábiles para el inicio del servicio. El derecho de arrepentimiento podría no ser aplicable.', 'woosales-arrepentimiento');
            }
        }

        return $advertencias;
    }

    /**
     * Procesar envío AJAX del formulario.
     */
    public function handle_submission(): void
    {
        check_ajax_referer('wa_form_nonce', 'nonce');

        // Honeypot: bots llenan campos ocultos — fake success silencioso
        if (!empty($_POST['wa_website'])) {
            wp_send_json_success([
                'codigo'             => str_pad((string) wp_rand(100, 999), 3, '0') . '-0000-' . current_time('Ymd'),
                'estado'             => WA_Status::label(WA_Status::default()),
                'advertencias'       => [],
                'enlace_seguimiento' => '',
            ]);
        }

        // CAPTCHA
        $captcha_token  = sanitize_text_field(wp_unslash($_POST['captcha_token'] ?? ''));
        $captcha_answer = sanitize_text_field(wp_unslash($_POST['captcha_answer'] ?? ''));

        if (!self::validar_captcha($captcha_token, $captcha_answer)) {
            wp_send_json_error([
                'errores' => [__('La verificación es incorrecta. Recargá la página e intentá de nuevo.', 'woosales-arrepentimiento')],
            ]);
        }

        $pedido_id      = sanitize_text_field(wp_unslash($_POST['pedido_id'] ?? ''));
        $email          = sanitize_email(wp_unslash($_POST['email'] ?? ''));
        $nombre         = sanitize_text_field(wp_unslash($_POST['nombre'] ?? ''));
        $fecha_reserva  = sanitize_text_field(wp_unslash($_POST['fecha_reserva'] ?? ''));
        $acepta_terminos = !empty($_POST['acepta_terminos']);

        // Validaciones básicas
        $errores = [];

        if (empty($pedido_id) || !is_numeric($pedido_id)) {
            $errores[] = __('Ingresá un número de pedido válido.', 'woosales-arrepentimiento');
        }

        if (empty($email) || !is_email($email)) {
            $errores[] = __('Ingresá un email válido.', 'woosales-arrepentimiento');
        }

        if (empty($nombre)) {
            $errores[] = __('Ingresá tu nombre.', 'woosales-arrepentimiento');
        }

        if (!$acepta_terminos) {
            $errores[] = __('Debés aceptar los términos y condiciones.', 'woosales-arrepentimiento');
        }

        if (!empty($errores)) {
            wp_send_json_error(['errores' => $errores]);
        }

        // Verificar duplicado activo para este pedido
        $existente = get_posts([
            'post_type'      => WA_Post_Type::CPT_SLUG,
            'meta_key'       => '_wa_pedido_id',
            'meta_value'     => $pedido_id,
            'posts_per_page' => 1,
            'post_status'    => 'private',
            'fields'         => 'ids',
        ]);

        if (!empty($existente)) {
            $codigo_existente = get_post_meta($existente[0], '_wa_codigo_tramite', true);
            wp_send_json_error([
                'errores' => [__('Ya existe una reclamación activa para este pedido.', 'woosales-arrepentimiento')],
                'codigo_existente' => $codigo_existente,
            ]);
        }

        // Validar fechas legales
        $advertencias_fecha = $this->validar_fechas_legales($pedido_id, $fecha_reserva);

        // Precargar datos del pedido si existe
        $order = wc_get_order($pedido_id);
        $date_created = $order ? $order->get_date_created() : null;
        $fecha_pedido = $date_created ? $date_created->date('d/m/Y') : '—';
        $nombre_pedido = $order ? ($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()) : '';

        // Si el nombre no coincide con el del pedido, usar el ingresado
        if (empty($nombre) && !empty($nombre_pedido)) {
            $nombre = $nombre_pedido;
        }

        // Generar código de trámite
        $codigo = $this->generar_codigo($pedido_id);

        // Crear CPT
        $post_id = wp_insert_post([
            'post_type'    => WA_Post_Type::CPT_SLUG,
            'post_title'   => sprintf(
                'Reclamación #%s — %s',
                $pedido_id,
                $nombre
            ),
            'post_status'  => 'private',
            'post_content' => '',
            'meta_input'   => [
                '_wa_pedido_id'      => $pedido_id,
                '_wa_codigo_tramite' => $codigo,
                '_wa_email_cliente'  => $email,
                '_wa_nombre_cliente' => $nombre,
                '_wa_estado'         => WA_Status::default(),
                '_wa_fecha_reserva'  => $fecha_reserva,
                '_wa_fecha_pedido'   => $fecha_pedido,
                '_wa_advertencias'   => $advertencias_fecha,
            ],
        ]);

        if (is_wp_error($post_id)) {
            wp_send_json_error(['errores' => [__('Error al crear la reclamación.', 'woosales-arrepentimiento')]]);
        }

        // Enviar emails
        $email_handler = WA_Loader::get('email');
        if ($email_handler) {
            $email_handler->enviar_cliente($post_id, $codigo, $email, $nombre);
            $email_handler->enviar_admin($post_id, $codigo, $pedido_id, $nombre, $email);
        }

        // Construir enlace de seguimiento
        $pagina_seguimiento = get_option('wa_pagina_seguimiento', '');
        $enlace_seguimiento = $pagina_seguimiento
            ? add_query_arg('codigo', $codigo, get_permalink((int) $pagina_seguimiento))
            : '';

        wp_send_json_success([
            'codigo'             => $codigo,
            'enlace_seguimiento' => $enlace_seguimiento,
            'advertencias'       => $advertencias_fecha,
            'estado'             => WA_Status::label(WA_Status::default()),
        ]);
    }
}
